'use strict';

/**
 * @ngdoc function
 * @name lyncDigitalApp.controller:editEmployerInfoCtrl
 * @description
 * # EditEmployerInfoCtrl
 * Controller of the lyncDigitalApp
 */
 
angular.module('lyncDigitalApp')
  .controller('editEmployerInfoController', function () {
  });
