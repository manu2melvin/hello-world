'use strict';

/**
 * @ngdoc function
 * @name lyncDigitalApp.controller:editCollegeInfoCtrl
 * @description
 * # EditCollegeInfoCtrl
 * Controller of the lyncDigitalApp
 */
 
angular.module('lyncDigitalApp')
  .controller('editCollegeInfoController', function () {
  });
