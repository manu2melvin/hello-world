'use strict';

/**
 * @ngdoc function
 * @name lyncDigitalApp.controller:editStudentInfoController
 * @description
 * # EditStudentInfoController
 * Controller of the lyncDigitalApp
 */
 
angular.module('lyncDigitalApp')
  .controller('editStudentInfoController', function () {
  });
